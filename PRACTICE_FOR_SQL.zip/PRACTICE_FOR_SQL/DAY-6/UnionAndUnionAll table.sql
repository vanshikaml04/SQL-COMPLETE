
create table append1 (C1 int, C2 nvarchar(255), C3 int);
insert into append1 values (1, 'A', 7),
                           (2, 'B', 8),
                           (3, 'C', 9);

create table append2 (C1 int, C2 nvarchar(255), C3 int);
insert into append2 values (11, 'AA', 17),
                           (2, 'B', 8),
                           (33, 'C1', 91);
