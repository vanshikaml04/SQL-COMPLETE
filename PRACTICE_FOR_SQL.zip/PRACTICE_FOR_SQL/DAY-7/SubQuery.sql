

select * from customers

select * from orders

select * from customers
where customer_id in (
	select distinct customer_id from orders where order_date between '2024-08-01' and '2024-08-30'
)

select * from customers
where customer_id in (
	select customer_id from orders where amount>70
)