
select a.c1, b.c1,b.c3 from table1 a left join table2 b on a.c1 = b.c1
