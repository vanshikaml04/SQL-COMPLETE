

select a.c1, b.c1,b.c3 from table1 a right join table2 b on a.c1=b.c1