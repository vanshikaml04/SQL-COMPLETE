--1 Select all columns from the emp table
select * from [dbo].[Employees]
--2
select firstName , lastname from [dbo].[Employees]
--3
select employeeId,firstname,lastname,department from [dbo].[Employees]
where department =/like 'IT' -- can also use = 
--4
select employeeId,firstname,lastname,Salary from [dbo].[Employees]
where salary>70000
--5
select employeeId,firstname,lastname from [dbo].[Employees]
order by lastname -- sorting means order by
--6
select distinct department from [dbo].[Employees]
--7
select department,count(*) from [dbo].[Employees]
group by Department
--8 
select department,max(salary) as max_sal from [dbo].[Employees]
group by Department
--9
select  avg(salary) as avg_sal from [dbo].[Employees]
where Department='FINANCE'
--10
select employeeId,firstname,lastname from [dbo].[Employees]
where lastname like 'm%'

