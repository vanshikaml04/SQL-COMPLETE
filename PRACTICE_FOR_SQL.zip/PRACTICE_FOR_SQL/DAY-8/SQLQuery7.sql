select * from Customers

select * from orders

select * from Products

--1
select c.CustomerID,c.CustomerName,o.OrderID  from customers c inner join orders o on o.CustomerID = c.CustomerID

--2 
select c.CustomerID,c.CustomerName,o.OrderID from customers c left join orders o on o.CustomerID = c.CustomerID
where o.OrderID is null

--3
select o.orderId,p.productId,p.productName,p.price from orders o inner join Products p on p.ProductID = o.ProductID

--4
select distinct c.CustomerName,o.OrderID from Customers c left join Orders o on o.CustomerID = c.CustomerID

--5 
select 