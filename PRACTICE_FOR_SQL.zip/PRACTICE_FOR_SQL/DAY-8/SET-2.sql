--1
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department = 'IT' and salary > 75000

--2
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department = 'HR' and salary < 60000

--3
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department != 'finance' 

--4
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department = 'finance' and Salary > 60000 and salary <70000

--5
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department = 'IT' and not salary > 60000

--6
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department in ('HR' ,'FINANCE','IT') and salary > 65000

-- 7
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where LastName like 'd%' and  Department = 'HR'

select * from [dbo].[Employees]

--8
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department not in ('IT') and salary > 70000

--9
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department in ('IT') and (salary > 65000 or firstname = 'Laura')

--10
select employeeid,firstname,lastname,department,salary from [dbo].[Employees]
where Department not in ('IT','HR') 