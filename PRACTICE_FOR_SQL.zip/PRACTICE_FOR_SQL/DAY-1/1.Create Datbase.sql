-- QUESTION 1 --> SELECT STATEMENT

CREATE DATABASE employee_details_final;
